# BMI_Calc Package
This is a BMI calculator package

## What it does
- Calculates user's bmi